# Eddy Trainer OS · Vercel 独立项目

已完成项目适配与本地权限测试；尚未在 Vercel 实际部署。页面仍是待同步初版。滴答连接已在对话中验证，但真实任务尚未写入本包；思源仍待连接。

## 最短部署路径：全程网页操作

1. 在 GitHub 登录，创建名为 eddy-trainer-os 的 **Private 私有仓库**。可勾选创建 README，便于进入文件上传界面。
2. 解压本 ZIP。进入 eddy-trainer-os-vercel 文件夹，将里面的 pages、server、scripts 三个文件夹及 package.json、vercel.json、README.md 上传到仓库根目录：Add file → Upload files。不要上传 ZIP 本身，不要多套一层目录。提交保存。
3. Vercel → Add New → Project → 导入 eddy-trainer-os 仓库。若列表没有仓库，给 Vercel 的 GitHub 集成授予这个私有仓库的访问权限。
4. Project Name：eddy-trainer-os。Framework Preset：Other。Root Directory：./。Build Command：npm run build（配置文件已指定）；Output Directory 保持默认、不手填 public 或 dist，构建程序使用 Vercel Build Output API。Node.js：22.x（package.json 已指定）。
5. 在部署页面 Environment Variables 添加 DASHBOARD_PASSWORD，值由你自己设置，至少16个字符，推荐密码管理器生成的随机密码。勾选你要使用的 Production / Preview 环境。不要写进源码，不需要提供给助手。
6. 点击 Deploy。Vercel 构建完成后给出实际域名。
7. 对外页：域名根路径 /。内部页：同域名 /dashboard。浏览器登录框的用户名固定 eddy，密码为上一步设置的值。

如果现有全项目 Deployment Protection 阻止匿名访问，应根据 Vercel 当前套餐和设置调整 Production 的 Vercel Authentication，才能让 Profile 公开；Dashboard 自带服务端验证仍会执行。不要为了公开 Profile 删除本项目的 Dashboard 验证代码。

## 上线后必须验证

- 无痕窗口打开 /：可以看到 Profile。
- 无痕窗口打开 /dashboard：先要求用户名/密码，取消或填错时不能看到任务。
- 填对用户名和密码：可以看到 Dashboard。
- /pages/dashboard.html、/dashboard.html、/server/dashboard.cjs 不可直接下载内部页面或源码。
- 手机移动网络打开两个网址，确认页面可达与登录正常。

如果看到 Dashboard access is not configured，检查环境变量至少16字符；修改环境变量后重新部署。变量未配置时服务返回503，不会降级公开。

## 安全与维护

采用 HTTPS + 服务端 HTTP Basic Auth，适用于单人轻量工作台。每次请求验证，采用恒定时间哈希比较。Dashboard 和认证失败响应均禁止缓存，禁止iframe嵌入及搜索索引。浏览器可能缓存本次会话的Basic凭证；退出时关闭无痕窗口。此版本没有多用户权限、验证码或持久登录失败限流，不作为多人CRM权限系统。

内部 HTML 放入函数包，不放入静态目录。构建静态白名单只复制 Profile；源码应保存在私有仓库，仓库协作者可以看到内部源文件。密码在 Vercel 运行环境读取，不打包进 HTML。

每次替换 pages/profile.html 或 pages/dashboard.html 并提交，Vercel 将自动重新构建。保持页面CSS/JS内嵌。不要把包含客户任务的原始数据或思源Token放进公开页面。构建不会主动查询滴答或思源；实时同步尚未实现。

## 文件与技术

- pages/profile.html：对外页面。
- pages/dashboard.html：内部快照，仅由受保护函数读取。
- server/dashboard.cjs：服务端验证与响应。
- scripts/build.cjs：生成 Vercel Build Output API v3。
- scripts/auth.test.cjs：缺失配置、错误认证、正确认证、禁止缓存、静态隔离测试。
- npm run build：构建，无第三方运行依赖。
- npm test：本地权限验证。

验证记录：上述权限与构建隔离测试通过。尚未完成真实 Vercel 路由、手机可达性或浏览器视觉验证；以首次部署验收为准。

官方参考：
https://vercel.com/docs/build-output-api/primitives
https://vercel.com/docs/projects/managing-projects
https://vercel.com/docs/git
