const crypto=require('node:crypto');
const fs=require('node:fs');
const path=require('node:path');
const hash=x=>crypto.createHash('sha256').update(x).digest();
module.exports=function(req,res){
 res.setHeader('Cache-Control','private, no-store, max-age=0');
 res.setHeader('CDN-Cache-Control','no-store');
 res.setHeader('Vercel-CDN-Cache-Control','no-store');
 res.setHeader('Vary','Authorization');
 res.setHeader('X-Robots-Tag','noindex, nofollow, noarchive');
 res.setHeader('X-Content-Type-Options','nosniff');
 res.setHeader('X-Frame-Options','DENY');
 res.setHeader('Referrer-Policy','no-referrer');
 res.setHeader('Content-Type','text/html; charset=utf-8');
 if(!['GET','HEAD'].includes(req.method)){
  res.setHeader('Allow','GET, HEAD');res.statusCode=405;return res.end('Method not allowed');
 }
 const expected=process.env.DASHBOARD_PASSWORD;
 if(!expected||expected.length<16){res.statusCode=503;return res.end('Dashboard access is not configured.');}
 const auth=req.headers.authorization||'';
 let provided='';
 if(auth.length<4096&&/^Basic [A-Za-z0-9+/]+=*$/i.test(auth)){
  provided=Buffer.from(auth.slice(6),'base64').toString('utf8');
 }
 if(!crypto.timingSafeEqual(hash(provided),hash('eddy:'+expected))){
  res.setHeader('WWW-Authenticate','Basic realm="Eddy Dashboard", charset="UTF-8"');
  res.statusCode=401;return res.end('Authentication required.');
 }
 res.statusCode=200;
 if(req.method==='HEAD')return res.end();
 return res.end(fs.readFileSync(path.join(__dirname,'dashboard.html')));
};
