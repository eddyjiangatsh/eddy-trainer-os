const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {execFileSync}=require('node:child_process');
execFileSync(process.execPath,[path.join(__dirname,'build.cjs')]);
const out=path.resolve(__dirname,'../.vercel/output');
const handler=require(path.join(out,'functions/dashboard.func/index.js'));
function request(auth,method='GET'){
 const res={headers:{},setHeader(k,v){this.headers[k]=v;},end(b=''){this.body=String(b);}};
 handler({method,headers:auth?{authorization:auth}:{}},res);return res;
}
test('access control and build isolation',()=>{
 delete process.env.DASHBOARD_PASSWORD;
 assert.equal(request().statusCode,503);
 process.env.DASHBOARD_PASSWORD='test-only-strong-password';
 for(const auth of [null,'Basic '+Buffer.from('eddy:wrong').toString('base64'),'Bearer nope','Basic malformed!']){
  const r=request(auth);assert.equal(r.statusCode,401);assert(!r.body.includes('今日待跟进'));
 }
 const credential='Basic '+Buffer.from('eddy:test-only-strong-password').toString('base64');
 const ok=request(credential);assert.equal(ok.statusCode,200);assert(ok.body.includes('今日待跟进'));assert.match(ok.headers['Cache-Control'],/no-store/);
 assert.equal(request(credential,'HEAD').body,'');assert.equal(request(credential,'POST').statusCode,405);
 assert.deepEqual(fs.readdirSync(path.join(out,'static')),['index.html']);
 assert(!fs.readFileSync(path.join(out,'static/index.html'),'utf8').includes('今日待跟进'));
 delete process.env.DASHBOARD_PASSWORD;
});
