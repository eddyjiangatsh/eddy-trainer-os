const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const out=path.join(root,'.vercel/output');
fs.rmSync(out,{recursive:true,force:true});
fs.mkdirSync(path.join(out,'static'),{recursive:true});
fs.mkdirSync(path.join(out,'functions/dashboard.func'),{recursive:true});
fs.copyFileSync(path.join(root,'pages/profile.html'),path.join(out,'static/index.html'));
fs.copyFileSync(path.join(root,'pages/dashboard.html'),path.join(out,'functions/dashboard.func/dashboard.html'));
fs.copyFileSync(path.join(root,'server/dashboard.cjs'),path.join(out,'functions/dashboard.func/index.js'));
fs.writeFileSync(path.join(out,'functions/dashboard.func/.vc-config.json'),JSON.stringify({runtime:'nodejs22.x',handler:'index.js',launcherType:'Nodejs',shouldAddHelpers:true}));
fs.writeFileSync(path.join(out,'config.json'),JSON.stringify({version:3,routes:[
 {src:'^/dashboard/?$',dest:'/dashboard'},
 {src:'^/$',dest:'/index.html'},
 {handle:'filesystem'},
 {src:'^/.*$',status:404}
]},null,2));
console.log('Built: public Profile + authenticated Dashboard. No private HTML in static output.');
